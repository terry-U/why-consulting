
  # Report Page Design

  This is a code bundle for Report Page Design. The original project is available at https://www.figma.com/design/b8lXDQDrj7w5rdJMFN1xRQ/Report-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
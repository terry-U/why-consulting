
  # 미래적 AI 상담사 챗봇 웹 서비스

  This is a code bundle for 미래적 AI 상담사 챗봇 웹 서비스. The original project is available at https://www.figma.com/design/Gw5gHkxYuaq5P7e5DHzM3n/%EB%AF%B8%EB%9E%98%EC%A0%81-AI-%EC%83%81%EB%8B%B4%EC%82%AC-%EC%B1%97%EB%B4%87-%EC%9B%B9-%EC%84%9C%EB%B9%84%EC%8A%A4.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  